(function(){
    return {
        a:params
    }
})()